﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace RescateCanApp.Migrations
{
    public partial class Add2 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
