﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace RescateCanApp.Migrations
{
    public partial class Adde : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "Email",
                table: "Foro",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Email",
                table: "Foro");
        }
    }
}
