﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace RescateCanApp.Migrations
{
    public partial class AddFotoUser : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
