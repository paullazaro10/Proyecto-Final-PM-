using System;
using System.ComponentModel.DataAnnotations;

namespace RescateCanApp.Models
{
    public class ForoMascota
    {
        public int Id { get; set; }
        public string Nombre { get; set; }
        public string Tema { get; set; }
        public string Foto { get; set; }
        public string Numero { get; set; }
        public string Descripcion { get; set; }
       [DataType(DataType.Date)]
       [Display(Name ="Fecha de publicacion")]
        public DateTime Fecha { get; set; }
        public string Email { get; set; }
    }
}