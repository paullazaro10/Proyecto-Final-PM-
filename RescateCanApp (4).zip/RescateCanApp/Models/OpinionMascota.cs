using System;
using System.ComponentModel.DataAnnotations;

namespace RescateCanApp.Models
{
    public class OpinionMascota
    {
        public int Id { get; set; }
        public string Opiniones { get; set; }
        public int Tema { get; set; }
        public string Nombre { get; set; }
        public string Foto { get; set; }
        
        [DataType(DataType.Date)]
        [Display(Name ="Fecha de publicacion")]
        public DateTime Fecha { get; set; }
        public string Email { get; set; }
        public string Numero { get; set; }
           
    }
}