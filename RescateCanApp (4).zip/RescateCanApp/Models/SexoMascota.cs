using System.Collections.Generic;

namespace RescateCanApp.Models
{
    public class SexoMascota
    {
        public int Id { get; set; }
        public string Sexo { get; set; }
        public List<Mascota> Mascotas { get; set; }
    }
}