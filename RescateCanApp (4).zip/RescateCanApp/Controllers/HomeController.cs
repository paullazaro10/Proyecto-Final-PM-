using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using RescateCanApp.Models;
using RescateCanApp.Datos;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Identity;

namespace RescateCanApp.Controllers
{
    public class HomeController : Controller
    {
        private MascotaContext _context;
      private SignInManager<IdentityUser> _signinmanager;
      private UserManager<IdentityUser> _userManager;

        public HomeController(MascotaContext c,UserManager<IdentityUser> um,SignInManager<IdentityUser> s){ 
            _signinmanager=s;
            _context = c;
            _userManager= um;
        }
        public IActionResult Index()
        {
            if(User.Identity.IsAuthenticated){

            
            var usuario = _userManager.FindByNameAsync(User.Identity.Name).Result;
            ViewBag.usuario=usuario;
            }
            return View();
        }

        public IActionResult Foro()
        {
            var noticias = _context.Foro.ToList();

            ViewBag.noticias = noticias;
            return View();
        }
        [HttpPost]
        public IActionResult Foro(ForoMascota m)
        {
            if(ModelState.IsValid){
                  var usuario = _userManager.FindByNameAsync(User.Identity.Name).Result as IdentityUser;
            
                _context.Add( new ForoMascota { 
                    Nombre = User.Identity.Name,
                    Tema = m.Tema,
                    Foto= usuario?.ConcurrencyStamp,
                    Descripcion=m.Descripcion,
                    Fecha = DateTime.Now,
                    Numero=usuario?.PhoneNumber,
                    Email=usuario?.Email,
                    });
                //guardarlos
                _context.SaveChanges();
                //redireccionar a index

                return RedirectToAction("foro");
            }

            return View(m);
        }
        //Listo ahora podemos grabar los temas del foro

       public IActionResult Opinion(int Id)
       {
           var noticias = _context.Opinion.Where(x=> x.Tema == Id).ToList();
            ViewBag.noticias = noticias;
            var noticia = _context.Foro.Where(x=> x.Id == Id).ToList();
            ViewBag.noticia = noticia;
            
           
           return View();
       }
       [HttpPost]
       public IActionResult Opinion(OpinionMascota m)
       {
            if (ModelState.IsValid) {
            var usuario = _userManager.FindByNameAsync(User.Identity.Name).Result as IdentityUser;    
            _context.Add( new OpinionMascota { Tema = m.Id,
             Opiniones = m.Opiniones,
             Nombre=User.Identity.Name,
             Fecha = DateTime.Now,
             Foto= usuario?.ConcurrencyStamp,
             Numero= usuario?.PhoneNumber,
             Email= usuario?.Email,
             });
            _context.SaveChanges();

                return RedirectToAction("opinion", new { Id = m.Id });
                
            }

            return View(m);
        }
        public IActionResult Comentario(int Id)
        {
            var notici = _context.Opinion.Where(x=> x.Id == Id).ToList();
            ViewBag.notici = notici;
            var noticia = _context.Comentario.Where(x=> x.Opinion == Id).ToList();
            ViewBag.noticia = noticia;

            return View();
        }
        
        [HttpPost]
        public IActionResult Comentario(ComentarioMascota m)
        {
            if (ModelState.IsValid) {
            var usuario = _userManager.FindByNameAsync(User.Identity.Name).Result as IdentityUser; 
            _context.Add( new ComentarioMascota { Opinion = m.Id,
             Comentario = m.Comentario,
             Nombre=User.Identity.Name,
             Fecha = DateTime.Now,
             Foto= usuario?.ConcurrencyStamp,
             Numero= usuario?.PhoneNumber,
             Email= usuario?.Email,
             });
            _context.SaveChanges();

                return RedirectToAction("comentario", new { Id = m.Id });
                
            }

            return View(m);
        }
          
    }    
}