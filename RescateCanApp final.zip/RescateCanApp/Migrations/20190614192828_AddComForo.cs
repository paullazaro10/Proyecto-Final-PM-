﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

namespace RescateCanApp.Migrations
{
    public partial class AddComForo : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "Descripcion",
                table: "Foro",
                nullable: true);

            migrationBuilder.AddColumn<DateTime>(
                name: "Fecha",
                table: "Foro",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<string>(
                name: "Foto",
                table: "Foro",
                nullable: true);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Descripcion",
                table: "Foro");

            migrationBuilder.DropColumn(
                name: "Fecha",
                table: "Foro");

            migrationBuilder.DropColumn(
                name: "Foto",
                table: "Foro");
        }
    }
}
