﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace RescateCanApp.Migrations
{
    public partial class AddNum : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "Email",
                table: "Opinion",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "Numero",
                table: "Opinion",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "Numero",
                table: "Foro",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<string>(
                name: "Email",
                table: "Comentario",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "Numero",
                table: "Comentario",
                nullable: false,
                defaultValue: 0);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Email",
                table: "Opinion");

            migrationBuilder.DropColumn(
                name: "Numero",
                table: "Opinion");

            migrationBuilder.DropColumn(
                name: "Numero",
                table: "Foro");

            migrationBuilder.DropColumn(
                name: "Email",
                table: "Comentario");

            migrationBuilder.DropColumn(
                name: "Numero",
                table: "Comentario");
        }
    }
}
