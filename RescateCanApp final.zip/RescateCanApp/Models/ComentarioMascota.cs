using System;
using System.ComponentModel.DataAnnotations;

namespace RescateCanApp.Models
{
    public class ComentarioMascota
    {
        public int Id { get; set; }
        public string Comentario { get; set; }
        public int Opinion { get; set; }
        public string Nombre { get; set; }
        
        [DataType(DataType.Date)]
        [Display(Name ="Fecha de publicacion")]
        public DateTime Fecha { get; set; }
        public string Foto { get; set; }
        public string Email { get; set; }
        public string Numero { get; set; }
    }
}